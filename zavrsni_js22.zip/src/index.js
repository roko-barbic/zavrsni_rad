const express = require('express')
const bodyParser = require('body-parser')
const cookieSession = require('cookie-session')
var mysql = require('mysql2');

const app = express()
const port = 3000

app.use(bodyParser.json())
app.use(express.static("public"))
app.use(cookieSession({
    name:"session",
    keys:["secretkey"],
    maxAge: 60*60*1000
}))

var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'korisnik',
  password : 'zavrsni',
  database : 'zavrsni'
});

app.get('/', (req, res) => {
    res.send("Hello world")
})

app.post('/register', (req, res) => {
    console.log("POST register")
    console.log(req.body)
    const username = req.body.username
    const email = req.body.email
    const password = req.body.password

    if(!username || !email || !password){
        console.log("login info not complete")
        res.sendStatus(400)
        return
    }

    connection.query('INSERT INTO user(username, email, password) VALUES (?,?,?)', [username, email, password], function (error, results, fields) {
        if (error){
            console.log(error)
            res.sendStatus(500)
            return
        }
        // connected!
        res.sendStatus(200)
      });
})

app.post('/login', (req, res) => {
    console.log("POST login")
    console.log(req.body)
    const username = req.body.username
    const password = req.body.password

    if(!username || !password){
        console.log("login info not complete")
        res.sendStatus(400)
        return
    }

    connection.query('SELECT ID, username, password FROM user WHERE username = ?', [username], function (error, results, fields) {
        if (error){
            console.log(error)
            res.sendStatus(500)
            return
        }
        // connected!
        console.log(results)
        if(results.length == 0 ||  results[0].password !== password){
            res.sendStatus(400)
            return
        }
        const user = {"id": results[0].ID,
                      "username": results[0].username}
        console.log(user)
        req.session.user = user
        res.sendStatus(200)
      });
})

app.get('/dvorana/:tjedan/:lokacija', (req, res) =>{
    const lokacija = req.params.lokacija
    const tjedan = req.params.tjedan
    connection.query('SELECT ID, name FROM dvorane where location = ? AND tjedan = ?', [lokacija, tjedan], function (error, results, fields) {
        if (error){
            console.log(error)
            res.sendStatus(500)
            return
        }
        // connected!
        res.json(results)
      });
})

app.get('/dvoranePriority/:p1/:p2/:p3', (req, res) =>{
    const p1 = req.params.p1
    const p2 = req.params.p2
    const p3 = req.params.p3
    result = {}
    const queryString = 'SELECT ID, name, times, location, tjedan FROM dvorane where ID = ?'
    connection.query(queryString, [p1], function (error, results, fields) {
        if (error){
            console.log(error)
            res.sendStatus(500)
            return
        }
        result.p1 = results[0]
        connection.query(queryString, [p2], function (error, results, fields) {
            if (error){
                console.log(error)
                res.sendStatus(500)
                return
            }
            result.p2 = results[0]
            connection.query(queryString, [p3], function (error, results, fields) {
                if (error){
                    console.log(error)
                    res.sendStatus(500)
                    return
                }
                // connected!
                result.p3 = results[0]
                res.json(result)
              });
          });
      });
})

app.post('/dvorana', (req, res) => {
    console.log("POST dvorana")
    console.log(req.body)
    const ime = req.body.name
    const tjedan = req.body.week
    const lokacija = req.body.location
    var vremena = req.body.times

    if(!ime || !tjedan || !lokacija || !vremena){
        console.log("dvorana info not complete")
        res.sendStatus(400)
        return
    }

    vremena = JSON.stringify(vremena)
    console.log(vremena.length)

    connection.query('INSERT INTO dvorane(name, location, times, tjedan) VALUES (?,?,?,?)', [ime, lokacija, vremena, tjedan], function (error, results, fields) {
        if (error){
            console.log(error)
            res.sendStatus(500)
            return
        }
        // connected!
        res.sendStatus(200)
      });

})


app.listen(port)